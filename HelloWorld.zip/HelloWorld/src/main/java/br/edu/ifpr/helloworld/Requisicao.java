package br.edu.ifpr.helloworld;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "requisicao", value = "/requisicao")
public class Requisicao extends HttpServlet {

    public void innit(){}

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String method = req.getMethod();
        String requestURI = req.getRequestURI();
        String protocol = req.getProtocol();
        String remoteAddr = req.getRemoteAddr();
        resp.getWriter().println("O método utilziado foi: " + method);
        resp.getWriter().println("URL de request é: " + requestURI);
        resp.getWriter().println("Protocolo: " + protocol);
        resp.getWriter().println("Endereço remoto: " + remoteAddr);

    }
    /*@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String url_requisicao = req.getMethod();
        resp.getWriter().println("O método utilziado foi: " + url_requisicao);
    }

    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String url_requisicao = req.getMethod();
        resp.getWriter().println("O método utilziado foi: " + url_requisicao);
    }

    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String url_requisicao = req.getMethod();
        resp.getWriter().println("O método utilziado foi: " + url_requisicao);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url_requisicao = req.getMethod();
        resp.getWriter().println("O método utilziado foi: " + url_requisicao);
    }

    @Override
    protected void doHead(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String url_requisicao = req.getMethod();
        resp.getWriter().println("O método utilziado foi: " + url_requisicao);
    }*/

    public void destroy(){}
}
