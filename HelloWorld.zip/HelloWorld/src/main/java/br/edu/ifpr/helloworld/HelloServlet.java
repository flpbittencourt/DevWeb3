package br.edu.ifpr.helloworld;

import java.io.*;

import jakarta.servlet.http.*;
import jakarta.servlet.annotation.*;

@WebServlet(name = "helloServlet", value = "/hello-servlet")
public class HelloServlet extends HttpServlet {
    private String message;

    public void init() {
        message = "Hello World!";
    }


    /*public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("text/html");
        String s;
        String a = request.getHeader(s = "user-agent");
        String b = request.getHeader(s = "accept-language");
        String c = request.getHeader(s ="accept-encoding");

        // Hello
        PrintWriter out = response.getWriter();
        out.println("<html><body>");
        out.println("<h1>" + message + "</h1>");
        out.println("</body></html>");

        out.println("<h1>user agente " + a + "<h1>");
        out.println("<h1>language " + b + "<h1>");
        out.println("<h1>accept encoding " + c + "<h1>");
    }*/

    public void destroy() {
    }
}
