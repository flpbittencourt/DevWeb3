package br.edu.ifpr.helloworld;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.io.PrintWriter;

@WebServlet(name = "cabecalho", value = "/cabecalho")
public class Cabecalho extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    resp.setContentType("text/html");
        PrintWriter out = resp.getWriter();
        out.println("<html>");
        out.println("<head>");
        out.println("<title>Informações de Cabeçalho</title>");
        out.println("</head>");
        out.println("<body>");
        out.println("<h1>Informações de Cabeçalho</h1>");
        out.println("<p><strong>Host:</strong> " + req.getHeader("Host") + "</p>");
        out.println("<p><strong>User-Agent:</strong> " + req.getHeader("User-Agent") + "</p>");
        out.println("<p><strong>Accept-Encoding:</strong> " + req.getHeader("Accept-Encoding") + "</p>");
        out.println("<p><strong>Accept-Language:</strong> " + req.getHeader("Accept-Language") + "</p>");
        out.println("</body>");
        out.println("</html>");
    }
}

